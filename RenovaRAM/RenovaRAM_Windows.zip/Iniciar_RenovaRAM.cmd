@echo off
setlocal
set "BASE=%~dp0"
if not exist "%BASE%RenovaRAM.ps1" exit /b 1
start "RenovaRAM" /min powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%BASE%RenovaRAM.ps1"
exit /b 0
