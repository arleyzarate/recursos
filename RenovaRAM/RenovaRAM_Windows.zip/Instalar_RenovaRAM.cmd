@echo off
setlocal EnableExtensions
chcp 65001 >nul
title RenovaRAM - Instalación local
cls
echo ===========================================
echo              RenovaRAM
 echo ===========================================
echo.
echo Este componente permite que su pagina web consulte la memoria real de Windows.
echo Se ejecutara en su cuenta de usuario cuando inicie sesion.
echo Para liberar memoria, RenovaRAM pedira su confirmacion en una ventana de Windows.
echo.
echo No requiere derechos de administrador. No expone servicios a Internet.
echo.
choice /c SN /n /m "Autoriza instalar y activar el componente [S/N]? "
if errorlevel 2 exit /b 0
set "DEST=%LOCALAPPDATA%\RenovaRAM"
if not exist "%DEST%" mkdir "%DEST%"
copy /y "%~dp0RenovaRAM.ps1" "%DEST%\RenovaRAM.ps1" >nul
if errorlevel 1 goto error
copy /y "%~dp0Iniciar_RenovaRAM.cmd" "%DEST%\Iniciar_RenovaRAM.cmd" >nul
if errorlevel 1 goto error
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v RenovaRAM /t REG_SZ /d "\"%DEST%\Iniciar_RenovaRAM.cmd\"" /f >nul
if errorlevel 1 goto error
call "%DEST%\Iniciar_RenovaRAM.cmd"
echo.
echo RenovaRAM preparado. Abra la pagina web y pulse Liberar.
echo Puede desinstalarlo con Desinstalar_RenovaRAM.cmd.
pause
exit /b 0
:error
echo.
echo No fue posible instalar todos los archivos. Revise los permisos.
pause
exit /b 1
