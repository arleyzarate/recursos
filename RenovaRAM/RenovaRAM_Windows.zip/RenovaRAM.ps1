# RenovaRAM 1.1 | Puente local de Windows | 23/oct/2026
# Ejecutar solo con consentimiento. Solo se comunica con la interfaz de Recursos
# o con un HTML local, mediante 127.0.0.1:18867.
$ErrorActionPreference = 'Stop'
$port = 18867
$folder = Join-Path $env:LOCALAPPDATA 'RenovaRAM'
if (-not (Test-Path -LiteralPath $folder)) { New-Item -ItemType Directory -Path $folder -Force | Out-Null }
$pidfile = Join-Path $folder 'servidor.pid'


Add-Type -ReferencedAssemblies 'System.Windows.Forms' -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
public static class RenovaNative {
    [StructLayout(LayoutKind.Sequential)]
    public struct MEMORYSTATUSEX {
        public UInt32 dwLength;
        public UInt32 dwMemoryLoad;
        public UInt64 ullTotalPhys;
        public UInt64 ullAvailPhys;
        public UInt64 ullTotalPageFile;
        public UInt64 ullAvailPageFile;
        public UInt64 ullTotalVirtual;
        public UInt64 ullAvailVirtual;
        public UInt64 ullAvailExtendedVirtual;
    }
    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX value);
    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern IntPtr OpenProcess(UInt32 access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool K32EmptyWorkingSet(IntPtr handle);
    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool CloseHandle(IntPtr handle);
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    public static extern UInt32 GetWindowThreadProcessId(IntPtr hwnd, out UInt32 pid);
}
'@

function Get-MemoryReadout {
    $s = New-Object RenovaNative+MEMORYSTATUSEX
    $s.dwLength = [System.Runtime.InteropServices.Marshal]::SizeOf([type][RenovaNative+MEMORYSTATUSEX])
    if (-not [RenovaNative]::GlobalMemoryStatusEx([ref]$s)) { throw 'Windows no entregó el estado de memoria.' }
    $gib = [double]1073741824
    $total = [math]::Round([double]$s.ullTotalPhys / $gib, 3)
    $available = [math]::Round([double]$s.ullAvailPhys / $gib, 3)
    $used = [math]::Round(([double]$s.ullTotalPhys - [double]$s.ullAvailPhys) / $gib, 3)
    $pct = if($s.ullTotalPhys -gt 0) { [math]::Round(100.0 * ($s.ullTotalPhys - $s.ullAvailPhys) / $s.ullTotalPhys, 2) } else { 0 }
    [ordered]@{ totalGiB=$total; availableGiB=$available; usedGiB=$used; percent=$pct }
}
function Get-RamModules {
    $ret = @()
    try {
        $devices = @(Get-CimInstance -ClassName Win32_PhysicalMemory -ErrorAction Stop | Where-Object { [double]$_.Capacity -gt 0 })
        foreach ($item in $devices) {
            $cap = [math]::Round([double]$item.Capacity / 1073741824, 3)
            if ($cap -le 0) { continue }
            $loc = [string]$item.DeviceLocator
            if ([string]::IsNullOrWhiteSpace($loc)) { $loc = [string]$item.BankLabel }
            if ([string]::IsNullOrWhiteSpace($loc)) { $loc = 'Ubicación desconocida' }
            $ret += [ordered]@{capacityGiB=$cap;locator=$loc;speedMHz=[int]$item.ConfiguredClockSpeed }
        }
    } catch { }
    return $ret
}
$modules = @(Get-RamModules)
function Get-State {
    $m = Get-MemoryReadout
    if($modules.Count -eq 0) {
        $m['modules'] = @([ordered]@{capacityGiB=$m.totalGiB;locator='Sistema · inventario no disponible'})
    } else {
        $m['modules'] = @($modules)
    }
    $m['ok'] = $true
    return $m
}
function Ask-Permission([array]$targets, [double]$used) {
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object System.Windows.Forms.Form
    $form.TopMost = $true
    $form.ShowInTaskbar = $false
    $form.StartPosition = 'CenterScreen'
    $form.Opacity = 0
    $form.Width = 1; $form.Height = 1
    try {
        $form.Show()
        $names = (@($targets | ForEach-Object { $_.ProcessName } | Select-Object -Unique) -join ', ')
        if($targets.Count -eq 0) { $names = 'No se detectaron procesos aptos' }
        $message = "¿Autoriza a RenovaRAM a intentar recuperar memoria residente?`r`n`r`n"
        $message += "RAM usada: $([math]::Round($used,1)) GiB`r`n"
        $message += "Aplicaciones: $names`r`n"
        $message += "Procesos candidatos: $($targets.Count)`r`n`r`n"
        $message += "Los programas seguirán abiertos, pero podrían responder más lento temporalmente."
        $answer = [System.Windows.Forms.MessageBox]::Show($form, $message, 'RenovaRAM | Confirmar liberación', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question, [System.Windows.Forms.MessageBoxDefaultButton]::Button2)
        return ($answer -eq [System.Windows.Forms.DialogResult]::Yes)
    } finally { $form.Close(); $form.Dispose() }
}
function Optimize-Memory {
    $before = Get-State
    # Lista intencionalmente limitada a aplicaciones comunes, nunca servicios ni procesos del sistema.
    $safeNames = @('chrome','msedge','firefox','Code','notepad','notepad++','mspaint','AcroRd32','FoxitPDFReader')
    $session = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
    $foreground = [uint32]0
    try { [void][RenovaNative]::GetWindowThreadProcessId([RenovaNative]::GetForegroundWindow(), [ref]$foreground) } catch {}
    $targets = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        ($safeNames -contains $_.ProcessName) -and $_.Id -ne $PID -and $_.Id -ne $foreground -and
        $_.SessionId -eq $session -and $_.WorkingSet64 -ge 268435456
    } | Sort-Object WorkingSet64 -Descending | Select-Object -First 8)
    if (-not (Ask-Permission -targets $targets -used $before.usedGiB)) {
        return [ordered]@{ok=$true;approved=$false;trimmed=0;before=$before;after=$before;message='El usuario canceló la intervención.'}
    }
    $success = 0
    foreach($p in $targets) {
        $handle = [IntPtr]::Zero
        try {
            # PROCESS_SET_QUOTA 0x100 | PROCESS_QUERY_LIMITED_INFORMATION 0x1000.
            $handle = [RenovaNative]::OpenProcess(0x1100, $false, [int]$p.Id)
            if($handle -ne [IntPtr]::Zero) {
                if([RenovaNative]::K32EmptyWorkingSet($handle)) { $success++ }
            }
        } catch { }
        finally { if($handle -ne [IntPtr]::Zero) { [void][RenovaNative]::CloseHandle($handle) } }
    }
    Start-Sleep -Milliseconds 1100
    $after = Get-State
    return [ordered]@{ok=$true;approved=$true;trimmed=$success;before=$before;after=$after;message='Se verificó el estado global de Windows.'}
}
function Write-Http([System.Net.Sockets.TcpClient]$client, [int]$code, [object]$obj, [string]$origin) {
    $json = ConvertTo-Json -InputObject $obj -Depth 8 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $status = if($code -eq 200){'OK'}elseif($code -eq 204){'No Content'}elseif($code -eq 403){'Forbidden'}elseif($code -eq 404){'Not Found'}else{'Bad Request'}
    $headers = "HTTP/1.1 $code $status`r`nContent-Type: application/json; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`n"
    if($origin -in @('https://arleyzarate.github.io','null')) {
        $headers += "Access-Control-Allow-Origin: $origin`r`nVary: Origin`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type`r`nAccess-Control-Allow-Private-Network: true`r`n"
    }
    $headers += "`r`n"
    $stream = $client.GetStream()
    $headbytes = [System.Text.Encoding]::ASCII.GetBytes($headers)
    $stream.Write($headbytes,0,$headbytes.Length)
    if($bytes.Length -gt 0) { $stream.Write($bytes,0,$bytes.Length) }
    $stream.Flush()
}
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
try {
    $listener.Start(16)
    try { [System.IO.File]::WriteAllText($pidfile, [string]$PID) } catch {}
    while($true) {
        $client = $null
        try {
            $client = $listener.AcceptTcpClient()
            $client.ReceiveTimeout = 6000; $client.SendTimeout = 6000
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
            $first = $reader.ReadLine()
            if (-not $first -or $first.Length -gt 2048) { continue }
            $parts = $first.Split(' ')
            if($parts.Length -ne 3) { continue }
            $headers = @{}
            for($i=0;$i -lt 55;$i++) {
                $line = $reader.ReadLine()
                if($null -eq $line -or $line -eq '') { break }
                if($line.Length -gt 4096) { break }
                $at = $line.IndexOf(':')
                if($at -gt 0) { $headers[$line.Substring(0,$at).ToLowerInvariant()] = $line.Substring($at+1).Trim() }
            }
            $origin = [string]$headers['origin']
            $hostName = [string]$headers['host']
            # Evita peticiones vía nombres arbitrarios (protección contra DNS rebinding).
            if($hostName -notin @("127.0.0.1:$port", "localhost:$port")) {
                Write-Http $client 403 @{ok=$false;error='Host no autorizado'} ''
                continue
            }
            if($origin -notin @('https://arleyzarate.github.io','null')) {
                Write-Http $client 403 @{ok=$false;error='Origen no autorizado'} ''
                continue
            }
            $method=$parts[0];$route=$parts[1]
            if($method -eq 'OPTIONS') { Write-Http $client 200 @{ok=$true} $origin; continue }
            if($method -eq 'GET' -and $route -eq '/api/estado') {
                Write-Http $client 200 (Get-State) $origin
            } elseif($method -eq 'POST' -and $route -eq '/api/liberar') {
                $length = 0
                [void][int]::TryParse([string]$headers['content-length'],[ref]$length)
                if($length -lt 1 -or $length -gt 64) { Write-Http $client 400 @{ok=$false;error='Solicitud inválida'} $origin; continue }
                $body = New-Object char[] $length
                $got = 0
                while($got -lt $length) { $step=$reader.Read($body,$got,$length-$got); if($step -le 0){break};$got += $step }
                if(($got -ne $length) -or ((-join $body) -ne 'liberar=1')) { Write-Http $client 400 @{ok=$false;error='Operación no reconocida'} $origin; continue }
                Write-Http $client 200 (Optimize-Memory) $origin
            } else { Write-Http $client 404 @{ok=$false;error='Ruta desconocida'} $origin }
        } catch {
            if($client) { try { Write-Http $client 400 @{ok=$false;error='No se pudo completar la solicitud'} '' } catch {} }
        } finally { if($client) {try{$client.Close()}catch{}} }
    }
} finally {
    try{$listener.Stop()}catch{}
    try{Remove-Item -LiteralPath $pidfile -Force -ErrorAction SilentlyContinue}catch{}
}
