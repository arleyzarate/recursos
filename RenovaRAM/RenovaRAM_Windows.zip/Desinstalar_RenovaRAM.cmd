@echo off
setlocal EnableExtensions
chcp 65001 >nul
title RenovaRAM - Desinstalar
cls
echo Este proceso desactiva RenovaRAM y elimina sus archivos locales.
choice /c SN /n /m "Desea continuar [S/N]? "
if errorlevel 2 exit /b 0
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v RenovaRAM /f >nul 2>&1
powershell.exe -NoProfile -Command "$dir=Join-Path $env:LOCALAPPDATA 'RenovaRAM'; $f=Join-Path $dir 'servidor.pid'; if(Test-Path $f){$idnum=[int](Get-Content $f -ErrorAction SilentlyContinue); $p=Get-CimInstance Win32_Process -Filter ('ProcessId='+$idnum) -ErrorAction SilentlyContinue; if($p -and $p.CommandLine -like '*RenovaRAM.ps1*'){Stop-Process -Id $idnum -ErrorAction SilentlyContinue}}"
set "DEST=%LOCALAPPDATA%\RenovaRAM"
if exist "%DEST%" rmdir /s /q "%DEST%"
echo RenovaRAM fue desactivado. Si quedan archivos ocupados, cierre sesion y repita.
pause
